@echo off
setlocal enabledelayedexpansion
title Phoenix P6 Engine - Portable Uninstall
REM ===========================================================================
REM  Removes the Phoenix P6 Engine add-in for the CURRENT USER: un-registers
REM  the XLL from Excel (HKCU OPEN keys) and deletes the install folder.
REM  The license file (%APPDATA%\PhoenixP6Engine\license.dat) is left in place.
REM ===========================================================================

set "DEST=%LOCALAPPDATA%\PhoenixP6Engine"

echo ==================================================
echo   Phoenix P6 Engine - Portable Uninstall
echo ==================================================
echo.

REM -- Excel must be closed to unregister / delete files ----------------------
tasklist /FI "IMAGENAME eq EXCEL.EXE" 2>nul | find /I "EXCEL.EXE" >nul
if not errorlevel 1 (
  echo  Microsoft Excel is running - it must be closed to uninstall.
  choice /C YN /M "Close Excel now"
  if errorlevel 2 goto cancelled
  taskkill /F /IM EXCEL.EXE >nul 2>&1
  timeout /t 2 >nul
)

for %%V in (16.0 15.0 14.0) do call :clean %%V

if exist "%DEST%" rmdir /S /Q "%DEST%" >nul 2>&1

echo.
echo  Uninstalled. Restart Excel to confirm the ribbon is gone.
echo  (Your license file was preserved.)
goto done

REM -- :clean  <officeVersion> ------------------------------------------------
:clean
set "KEY=HKCU\Software\Microsoft\Office\%~1\Excel\Options"
for %%S in (OPEN OPEN1 OPEN2 OPEN3 OPEN4 OPEN5 OPEN6 OPEN7 OPEN8 OPEN9) do (
  reg query "%KEY%" /v %%S 2>nul | find /I "PhoenixP6Engine" >nul && (
    reg delete "%KEY%" /v %%S /f >nul 2>&1
    echo  Removed Office %~1 registration (%%S)
  )
)
goto :eof

:cancelled
echo  Cancelled - nothing was changed.
goto done

:done
echo.
pause
endlocal
