@echo off
setlocal enabledelayedexpansion
title Phoenix P6 Engine - Portable Install
REM ===========================================================================
REM  Phoenix P6 Engine - Portable installer (NO .exe, NO admin rights)
REM
REM  Alternative to the EXE installer for locked-down machines. Copies the
REM  add-in files to %LOCALAPPDATA%\PhoenixP6Engine and registers the XLL in
REM  Excel for the CURRENT USER only (HKCU) - identical to what the EXE does.
REM
REM  If your IT policy blocks .bat too, use the fully-manual steps in README.txt
REM  (Excel > File > Options > Add-ins > Manage: Excel Add-ins > Go > Browse).
REM ===========================================================================

set "SRC=%~dp0"
set "DEST=%LOCALAPPDATA%\PhoenixP6Engine"
set "XLL=%DEST%\PhoenixP6Engine.xll"

echo ==================================================
echo   Phoenix P6 Engine - Portable Install (no admin)
echo ==================================================
echo.

REM -- verify the payload was fully extracted ---------------------------------
if not exist "%SRC%PhoenixP6Engine.xll"      goto missing
if not exist "%SRC%p6_core.dll"              goto missing
if not exist "%SRC%x64\SQLite.Interop.dll"   goto missing

REM -- Excel must be closed to replace the files ------------------------------
tasklist /FI "IMAGENAME eq EXCEL.EXE" 2>nul | find /I "EXCEL.EXE" >nul
if not errorlevel 1 (
  echo  Microsoft Excel is running - it must be closed to install.
  choice /C YN /M "Close Excel now"
  if errorlevel 2 goto cancelled
  taskkill /F /IM EXCEL.EXE >nul 2>&1
  timeout /t 2 >nul
)

REM -- copy files (same layout as the EXE installer) --------------------------
if not exist "%DEST%\x64" mkdir "%DEST%\x64" >nul 2>&1
copy /Y "%SRC%PhoenixP6Engine.xll"    "%DEST%\"     >nul || goto copyfail
copy /Y "%SRC%p6_core.dll"            "%DEST%\"     >nul || goto copyfail
copy /Y "%SRC%x64\SQLite.Interop.dll" "%DEST%\x64\" >nul || goto copyfail

REM -- strip Mark-of-the-Web (downloaded-file block) - best effort -----------
for %%F in ("%DEST%\PhoenixP6Engine.xll" "%DEST%\p6_core.dll" "%DEST%\x64\SQLite.Interop.dll") do (
  del "%%~fF:Zone.Identifier" >nul 2>&1
)

REM -- register in Excel (HKCU) for whichever Office versions are present ------
set "REGISTERED="
for %%V in (16.0 15.0 14.0) do call :register %%V

if not defined REGISTERED (
  echo.
  echo  Files copied, but no Office registry key was found to auto-register.
  echo  Add it once, manually:
  echo    Excel ^> File ^> Options ^> Add-ins ^> Manage: Excel Add-ins ^> Go ^> Browse
  echo    then pick:  %XLL%
  goto done
)

echo.
echo  Installed and registered for the current user.
echo  Location: %DEST%
echo  Start Excel - the Phoenix ribbon tabs will appear.
goto done

REM -- :register  <officeVersion> --------------------------------------------
:register
set "VER=%~1"
REM only if this Office version is actually present
reg query "HKCU\Software\Microsoft\Office\%VER%\Excel" >nul 2>&1
if errorlevel 1 reg query "HKLM\Software\Microsoft\Office\%VER%\Excel" >nul 2>&1
if errorlevel 1 reg query "HKLM\Software\WOW6432Node\Microsoft\Office\%VER%\Excel" >nul 2>&1
if errorlevel 1 goto :eof
set "KEY=HKCU\Software\Microsoft\Office\%VER%\Excel\Options"
REM already registered in any slot? then we are done for this version
for %%S in (OPEN OPEN1 OPEN2 OPEN3 OPEN4 OPEN5 OPEN6 OPEN7 OPEN8 OPEN9) do (
  reg query "%KEY%" /v %%S 2>nul | find /I "PhoenixP6Engine" >nul && (set "REGISTERED=1" & goto :eof)
)
REM find the first free OPEN slot so we never clobber another add-in
set "SLOT="
reg query "%KEY%" /v OPEN >nul 2>&1 || set "SLOT=OPEN"
if not defined SLOT for %%I in (1 2 3 4 5 6 7 8 9) do if not defined SLOT (
  reg query "%KEY%" /v OPEN%%I >nul 2>&1 || set "SLOT=OPEN%%I"
)
if not defined SLOT goto :eof
reg add "%KEY%" /v !SLOT! /t REG_SZ /d "\"%XLL%\"" /f >nul
set "REGISTERED=1"
echo  Registered for Office %VER%  (slot !SLOT!)
goto :eof

:missing
echo  ERROR: required files are missing next to this script.
echo  Extract the WHOLE zip first (including the x64 folder), then run install.bat.
goto done
:copyfail
echo  ERROR: could not copy files to %DEST%.
echo  Close Excel and run install.bat again.
goto done
:cancelled
echo  Cancelled - nothing was changed.
goto done

:done
echo.
pause
endlocal
