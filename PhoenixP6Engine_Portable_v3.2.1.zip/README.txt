===========================================================================
 Phoenix P6 Engine - Portable install (no .exe, no admin rights)
===========================================================================

This package installs the Excel add-in WITHOUT running an .exe installer,
for machines where IT blocks executables. Nothing here runs as a standalone
program - Excel simply loads the add-in file (.xll).

WHAT IS IN THIS ZIP
  PhoenixP6Engine.xll        the Excel add-in
  p6_core.dll                native engine (must sit next to the .xll)
  x64\SQLite.Interop.dll     database support (keep it in the x64 folder)
  install.bat                one-click install + register for your user
  uninstall.bat              removes it again
  README.txt                 this file

BEFORE YOU START
  1) If you downloaded this as a zip, right-click the ZIP first -> Properties
     -> tick "Unblock" -> OK.  (Removes the internet "block" Windows adds.)
  2) Extract the WHOLE zip to a folder, keeping the x64 sub-folder.
  3) Close Microsoft Excel.

-----------------------------------------------------------------------------
 METHOD A - automatic (recommended)
-----------------------------------------------------------------------------
  Double-click  install.bat
  It copies the files to  %LOCALAPPDATA%\PhoenixP6Engine  and registers the
  add-in in Excel for your user only (no admin needed). Start Excel - the
  Phoenix ribbon tabs appear.

  To remove it later: double-click  uninstall.bat

-----------------------------------------------------------------------------
 METHOD B - fully manual (if .bat is also blocked)
-----------------------------------------------------------------------------
  This needs no .exe and no script - only Excel's own menus.

  1) Move this extracted folder somewhere permanent, e.g.
        C:\Users\<you>\AppData\Local\PhoenixP6Engine
     (Keep PhoenixP6Engine.xll, p6_core.dll and the x64 folder together.)
  2) Open Excel.
  3) File > Options > Add-ins.
  4) At the bottom, "Manage:" choose  Excel Add-ins  and click  Go...
  5) Click  Browse...  and select  PhoenixP6Engine.xll  from the folder above.
  6) Make sure it is ticked, click OK. The Phoenix ribbon tabs appear.

  To remove it: File > Options > Add-ins > Manage: Excel Add-ins > Go >
  untick "Phoenix P6 Engine" (or select it and Remove).

-----------------------------------------------------------------------------
 TROUBLESHOOTING
-----------------------------------------------------------------------------
  * Ribbon does not appear:
      - Make sure p6_core.dll and x64\SQLite.Interop.dll stayed next to the
        .xll (same folder / same x64 sub-folder).
      - Excel must be 64-bit (this build is 64-bit only). Check:
        Excel > File > Account > About Excel (top line says 32-bit or 64-bit).
      - If Excel says the add-in is blocked, right-click the .xll ->
        Properties -> Unblock, then re-add it.
  * "The file is not a valid add-in": you likely have 32-bit Excel. Ask for
    the 32-bit build.
  * Still blocked by IT policy (Trust Center disables all add-ins): that is a
    company policy - contact your IT to allow this add-in.

  Support: https://www.linkedin.com/in/omar-adel-badawy-02a8b7a2/
===========================================================================
